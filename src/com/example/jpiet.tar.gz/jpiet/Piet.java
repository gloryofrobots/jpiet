package com.example.jpiet;

import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;

public class Piet {
    public static CodelTableModel createModel(String _filename){
        try {
            BufferedImage img = ImageIO.read(new File(_filename));
            CodelTableModel model = new CodelTableModel(img.getWidth(), img.getHeight());

            for(int y = 0; y < img.getHeight(); y++){
                for(int x = 0; x < img.getWidth(); x++){
                    int pixel = img.getRGB(x, y);
                    int R = (pixel & 0xFF0000) >> 16;
                    int G = (pixel & 0xFF00) >> 8;
                    int B = (pixel & 0xFF);

                    CodelColor color = CodelColor.findColor(R, G, B);
                    model.set(x, y, color);
                }
            }
            return model;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
      return  null;
    }
    //CODEL SIZE !!!!!!!!
    public static void main(String[] args) {
        //CodelTableModel model = FakeData.getPietModel();
        //CodelTableModel model = Piet.createModel("/home/gloryofrobots/bin/hipi/helloWorld.png");
        CodelTableModel model = Piet.createModel("/home/gloryofrobots/bin/hipi/piet.png");
        //CodelTableModel model = Piet.createModel("/home/gloryofrobots/bin/hipi/addition.png");
        Logger logger = new LoggerJavaSdkStdOut();

        InOutSystem inOutSystem = new InOutSystemJDK();
        PietMachine machine = new PietMachine(inOutSystem);

        Interpreter interpreter = new Interpreter(logger, machine, false);
        interpreter.setInput(model);

        interpreter.run();
    }
}