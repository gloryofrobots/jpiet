/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.example.jpiet;

public class PietMachineStack extends Stack<Integer>{

}
