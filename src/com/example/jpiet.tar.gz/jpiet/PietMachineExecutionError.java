package com.example.jpiet;


public class PietMachineExecutionError extends Exception {
    PietMachineExecutionError(String _message){
        super(_message);
    }
}
